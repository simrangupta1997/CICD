import argparse
import json
import logging
import os
import pathlib
import time

from ib_cicd.ib_helpers import (
    check_job_status_build,
    compile_solution_build,
    create_deployment,
    create_folder_if_it_does_not_exists,
    generate_flow,
    get_app_details,
    get_deployment_details,
    publish_advanced_app,
    read_file_through_api,
    wait_until_job_finishes,
    upload_file,
)
from ib_cicd.rebuild_utils import (
    create_build_project,
    get_schema,
    get_settings,
    get_udfs,
    get_validations,
    map_field_ids,
    modify_schema,
    modify_settings,
    modify_validations,
    post_schema,
    post_settings,
    post_validations,
    sanitize_udf_payload,
)


def download_binary(ib_host, api_token, solution_path):
    """
    Download a file from the Instabase API.

    Args:
        ib_host: The Instabase host URL
        api_token: API token for authentication
        solution_path: Path to the solution in Instabase

    Returns:
        The binary content of the downloaded file

    Raises:
        Exception: If download fails
    """
    response = read_file_through_api(ib_host, api_token, solution_path)
    if not response or response.status_code != 200:
        raise Exception(
            f"Failed to download file from {solution_path}. "
            f"Response code: {response.status_code}"
        )

    solution_name = pathlib.Path(solution_path).name
    with open(solution_name, "wb") as fd:
        fd.write(response.content)
    return response.content


def download_file(ib_host, api_token, solution_path):
    """
    Download a JSON file from the Instabase API.

    Args:
        ib_host: The Instabase host URL
        api_token: API token for authentication
        solution_path: Path to the solution in Instabase

    Returns:
        The content of the downloaded file

    Raises:
        Exception: If download fails
    """
    response = read_file_through_api(ib_host, api_token, solution_path)
    if not response or response.status_code != 200:
        raise Exception(
            f"Failed to download file from {solution_path}. "
            f"Response code: {response.status_code}"
        )

    solution_name = pathlib.Path(solution_path).name
    try:
        json_content = json.loads(response.content.decode("utf-8"))
        with open(solution_name, "w") as fd:
            json.dump(json_content, fd, indent=4, sort_keys=True)
        return response.content
    except json.JSONDecodeError as e:
        raise Exception(f"Invalid JSON content in downloaded file: {e}")


def save_to_file(data, file_name):
    """Save data to a JSON file."""
    with open(file_name, "w") as f:
        json.dump(data, f, indent=4, sort_keys=True)


def read_binary(file_name="codelabs.ibflowbin"):
    """Read binary data from a file."""
    with open(file_name, "rb") as f:
        data = f.read()
    return data


def load_from_file(file_name):
    """Load data from a JSON file."""
    if os.path.exists(file_name):
        with open(file_name, "r") as f:
            return json.load(f)
    else:
        logging.error(f"File not found: {file_name}")
        raise FileNotFoundError(f"File not found: {file_name}")


def load_config(file_path="config.json"):
    """Load configuration from a JSON file."""
    try:
        with open(file_path, "r") as config_file:
            config = json.load(config_file)
        logging.info("Configuration file loaded successfully")
        return config
    except FileNotFoundError:
        raise FileNotFoundError(f"Configuration file '{file_path}' not found")
    except json.JSONDecodeError:
        raise Exception(f"Configuration file '{file_path}' contains invalid JSON")
    except Exception as e:
        raise Exception(f"Error loading config file: {e}")


def fetch_details(config):
    """Fetch phase information (settings, schema, validations, etc.)."""
    source_host_url = os.environ.get("SOURCE_HOST_URL")
    source_token = os.environ.get("SOURCE_TOKEN")
    source_project_id = config["source"]["project_id"]

    try:
        projects = get_settings(source_project_id, source_token, source_host_url)
        save_to_file(projects, "fetched_settings.json")

        udfs = get_udfs(source_project_id, source_token, source_host_url)
        save_to_file(udfs, "fetched_udfs.json")

        schema = get_schema(source_project_id, source_token, source_host_url)
        save_to_file(schema, "fetched_schema.json")

        validations = get_validations(source_project_id, source_token, source_host_url)
        save_to_file(validations, "fetched_validations.json")

    except Exception as e:
        logging.error(f"Error fetching phase data: {e}")
        raise


def rebuild_project(config):
    """Rebuild the project in the target environment."""
    target_token = os.environ.get("TARGET_TOKEN")
    target_host_url = os.environ.get("TARGET_HOST_URL")
    target_org = config["target"]["org"]
    target_workspace = config["target"]["workspace"]
    source_project_id = config["source"]["project_id"]

    try:
        # Load fetched data
        projects = load_from_file("fetched_settings.json")
        udfs = load_from_file("fetched_udfs.json")
        schema = load_from_file("fetched_schema.json")
        validations = load_from_file("fetched_validations.json")

        # Create build project
        target_project_id = config["target"].get("project_id")
        if not target_project_id:
            project_name = next(
                (
                    item["name"]
                    for item in projects["projects"]
                    if item["id"] == source_project_id
                ),
                None,
            )
            if not project_name:
                raise ValueError("Source project not found in settings")

            response = create_build_project(
                project_name,
                target_token,
                target_host_url,
                target_org,
                target_workspace,
            )
            target_project_id = response["project_id"]

        # Modify and post settings, schema, and validations
        modified_settings = modify_settings(source_project_id, projects)
        post_settings(
            target_project_id, target_token, target_host_url, modified_settings
        )

        sanitized_udfs = sanitize_udf_payload(udfs)
        target_schema = get_schema(target_project_id, target_token, target_host_url)
        modified_schema = modify_schema(
            target_schema,
            schema,
            target_project_id,
            target_token,
            target_host_url,
            sanitized_udfs,
        )
        result = post_schema(
            target_project_id, target_token, target_host_url, modified_schema
        )

        mappings = map_field_ids(schema, result)
        modified_validations = modify_validations(
            get_validations(target_project_id, target_token, target_host_url),
            validations,
            target_project_id,
            target_token,
            target_host_url,
            sanitized_udfs,
            mappings,
        )
        for payload in modified_validations:
            post_validations(target_project_id, target_token, target_host_url, payload)

    except Exception as e:
        logging.error(f"Error during project rebuild: {e}")
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--compile_solution", action="store_true")
    parser.add_argument("--download_binary", action="store_true")
    parser.add_argument("--upload_binary", action="store_true")
    parser.add_argument("--publish_advanced_app", action="store_true")
    parser.add_argument("--create_deployment", action="store_true")
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()

    try:
        config = load_config("config.json")
        source = config["source"]
        target = config["target"]

        # Extract source config
        source_host_url = os.environ.get("SOURCE_HOST_URL")
        if not source_host_url:
            raise ValueError("Source host URL cannot be empty")

        source_token = os.environ.get("SOURCE_TOKEN")
        if not source_token:
            raise ValueError("Source token cannot be empty")

        project_id = source["project_id"]
        if not project_id:
            raise ValueError("Project ID cannot be empty")

        source_org = source["org"]
        if not source_org:
            raise ValueError("Source org cannot be empty")

        source_workspace = source["workspace"]
        if not source_workspace:
            raise ValueError("Source workspace cannot be empty")

        app_id = source.get("app_id")
        deployment_id = source.get("deployment_id")

        # Extract target config
        target_host_url = os.environ.get("TARGET_HOST_URL")
        if not target_host_url:
            raise ValueError("Target host URL cannot be empty")

        target_token = os.environ.get("TARGET_TOKEN")
        if not target_token:
            raise ValueError("Target token cannot be empty")

        target_org = target["org"]
        if not target_org:
            raise ValueError("Target org cannot be empty")

        target_workspace = target["workspace"]
        if not target_workspace:
            raise ValueError("Target workspace cannot be empty")

        # Compile the binary
        if args.compile_solution:
            logging.info("Compiling solution binary...")
            response = generate_flow(source_host_url, source_token, project_id)
            job_id = response["job_id"]
            wait_until_job_finishes(source_host_url, job_id, "async", source_token)
            solution_path = (
                f"{source_org}/{source_workspace}/fs/Instabase Drive/aihub/"
                f"{project_id}/project/flows/codelabs.ibflow"
            )
            compile_solution_build(source_host_url, source_token, solution_path)
            time.sleep(3)

        # Download the solution
        if args.download_binary:
            binary_path = (
                f"{source_org}/{source_workspace}/fs/Instabase Drive/aihub/"
                f"{project_id}/project/flows/codelabs.ibflowbin"
            )
            data_path = (
                f"{source_org}/{source_workspace}/fs/Instabase Drive/aihub/"
                f"{project_id}/project/flows/project_snapshot.json"
            )

            logging.info("Downloading binary and project snapshot...")
            download_file(source_host_url, source_token, data_path)
            download_binary(source_host_url, source_token, binary_path)

            logging.info("Fetching schema details for rebuilding...")
            fetch_details(config)

            if app_id:
                logging.info("Getting app details...")
                response = get_app_details(
                    source_host_url, source_token, source_org, app_id
                )
                details = response.get("solution", {})
                save_to_file(details, "app_details.json")

            if deployment_id:
                logging.info("Getting deployment details...")
                response = get_deployment_details(
                    source_host_url, source_token, source_org, deployment_id
                )
                save_to_file(response, "deployment_details.json")

        # Upload binary to target
        if args.upload_binary:
            logging.info("Uploading solution binary to target system...")
            target_path = f"{target_org}/{target_workspace}/fs/Instabase Drive/aihub/{project_id}/"
            create_folder_if_it_does_not_exists(
                target_host_url, target_token, target_path
            )

            target_binary_path = target_path + "codelabs.ibflowbin"
            binary_content = read_binary()
            upload_file(
                target_host_url, target_token, target_binary_path, binary_content
            )

        # Publish advanced app
        if args.publish_advanced_app:
            if not app_id:
                logging.error("Source App ID not provided")
                return

            app_details = load_from_file("app_details.json")
            solution_path = app_details.get("solution_path")
            if solution_path:
                image_data = read_file_through_api(
                    source_host_url, source_token, solution_path + "/icon.png"
                )
                icon_path = target_path + "icon.png"
                upload_file(target_host_url, target_token, icon_path, image_data)
            else:
                logging.warning(
                    "Image path not found in app details. Skipping icon upload."
                )

            logging.info("Publishing advanced app...")
            payload = {
                "ibflowbin_path": target_binary_path,
                "icon_path": icon_path,
                "app_detail": {
                    "name": app_details["name"],
                    "version": app_details["version"],
                    "description": app_details["summary"],
                    "visibility": app_details["visibility"],
                    "release_notes": app_details["description"],
                    "billing_model": "default",
                },
            }
            response = publish_advanced_app(
                target_host_url, target_token, payload, target_org
            )
            new_app_id = check_job_status_build(
                target_host_url, target_token, response["job_id"]
            )
            logging.info("App published successfully")

        # Create deployment
        if args.create_deployment:
            if not deployment_id:
                logging.error("Source Deployment ID not provided")
                return

            details = load_from_file("deployment_details.json")
            logging.info("Creating deployment...")
            payload = {
                "name": details["name"],
                "workspace": target_workspace,
                "deployed_solution_id": new_app_id,
                "description": details["description"],
                "human_review_mode": details["human_review_mode"],
                "human_review_level": details["human_review_level"],
            }
            create_deployment(target_host_url, target_token, payload, target_org)
            logging.info("Deployment created successfully")

        # Rebuild project
        if args.rebuild:
            rebuild_project(config)
            logging.info("Rebuild completed successfully!")

    except Exception as e:
        logging.error(f"Error in main execution: {e}")
        raise


if __name__ == "__main__":
    main()
