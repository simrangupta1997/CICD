import argparse
import json
import logging
import os
import pathlib
import re
import shutil
import time

from dotenv import load_dotenv

from ib_cicd.ib_helpers import (
    check_job_status_build,
    compile_solution,
    copy_file_within_ib,
    create_deployment,
    delete_folder_or_file_from_ib,
    get_app_details,
    get_deployment_details,
    list_directory,
    publish_advanced_app,
    read_file_through_api,
    unzip_files,
    upload_file,
)
from ib_cicd.migration_helpers import (
    download_dependencies_from_dev_and_upload_to_prod,
    download_solution,
    publish_dependencies,
)
from ib_cicd.promote_build_solution import (
    load_config,
    load_from_file,
    read_binary,
    save_to_file,
)

load_dotenv()


def copy_solution_to_working_dir(
    source_host, source_token, source_dir, rel_flow_path, new_solution_dir
):
    """Copy solution files to working directory.

    Args:
        source_host: Source Instabase host
        source_token: Source API token
        source_dir: Source directory path
        rel_flow_path: Relative flow path
        new_solution_dir: New solution directory path
    """
    flow_path = os.path.join(source_dir, rel_flow_path)
    modules_path = os.path.join(source_dir, *rel_flow_path.split("/")[:-1], "modules")
    for path in [flow_path, modules_path]:
        new_path = path.replace(source_dir, new_solution_dir)
        copy_file_within_ib(
            source_host, source_token, path, new_path, use_clients=False
        )


def upload_zip_to_instabase(target_path, target_host, target_token, solution_name):
    """Create and upload solution zip archive to Instabase.

    Args:
        target_path: Target Instabase path
        target_host: Target Instabase host
        target_token: Target API token
        solution_name: Name of solution

    Returns:
        Upload response from API

    Raises:
        Exception: If zip creation or upload fails
    """
    try:
        shutil.make_archive("solution", "zip", "solution")
        path_to_upload = os.path.join(target_path, f"{solution_name}.zip")

        with open("solution.zip", "rb") as upload_data:
            return upload_file(target_host, target_token, path_to_upload, upload_data)
    except Exception as e:
        logging.error(f"Failed to upload zip to Instabase: {e}")
        raise


def version_tuple(v):
    """Convert version string to tuple of integers.

    Args:
        v: Version string in format "x.y.z"

    Returns:
        Tuple of version integers
    """
    return tuple(map(int, (v.split("."))))


def get_latest_binary_path(api_token, ib_host, solution_path):
    """Get path of latest versioned .ibflowbin file.
    If no versioned binary found, return path of simple named binary if exists.

    Args:
        api_token: API token
        ib_host: Instabase host
        solution_path: Path to search for binaries

    Returns:
        Path to latest binary file or simple named binary file

    Raises:
        Exception: If no valid binaries found
    """
    paths = list_directory(ib_host, solution_path, api_token)
    paths = [p for p in paths if p.endswith(".ibflowbin")]
    if not paths:
        raise Exception(f"No .ibflowbin files found in {solution_path}")

    versioned_binaries = []
    simple_binaries = []

    for path in paths:
        filename = os.path.basename(path)
        version = filename.replace(".ibflowbin", "")
        if re.fullmatch(r"\d+\.\d+\.\d+", version):
            versioned_binaries.append(path)
        else:
            simple_binaries.append(path)

    if versioned_binaries:
        latest_version = "0.0.0"
        latest_path = None
        for path in versioned_binaries:
            filename = os.path.basename(path)
            version = filename.replace(".ibflowbin", "")
            if version_tuple(version) > version_tuple(latest_version):
                latest_version = version
                latest_path = path
        return latest_path
    elif simple_binaries:
        return simple_binaries[0]
    else:
        raise Exception("No valid versioned or simple named .ibflowbin files found")


def parse_dependencies(dependencies):
    """Parse dependency string into dictionary.

    Args:
        dependencies: List of dependencies in format ["name==version"]

    Returns:
        Dictionary mapping dependency names to versions
    """
    if not dependencies:
        return {}
    try:
        return {
            m.split("==")[0].strip(): m.split("==")[1].strip()
            for m in dependencies
            if "==" in m
        }
    except Exception as e:
        logging.error(f"Error parsing dependencies: {e}")
        return {}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--compile_solution", action="store_true")
    parser.add_argument("--promote_solution_to_target", action="store_true")
    parser.add_argument("--upload_dependencies", action="store_true")
    parser.add_argument("--download_solution", action="store_true")
    parser.add_argument("--publish_advanced_app", action="store_true")
    parser.add_argument("--create_deployment", action="store_true")
    args = parser.parse_args()

    try:
        # Load configuration
        config = load_config("config.json")

        # Source environment config
        source_config = config["source"]
        SOURCE_IB_HOST = os.environ.get("SOURCE_HOST_URL")
        SOURCE_IB_API_TOKEN = os.environ.get("SOURCE_TOKEN")
        FLOW_PATH = source_config.get("flow_path")
        app_id = source_config.get("app_id")
        deployment_id = source_config.get("deployment_id")
        SOURCE_ORG = source_config.get("org")
        SOURCE_WORKSPACE = source_config.get("workspace")

        if FLOW_PATH:
            SOURCE_SOLUTION_DIR = "/".join(FLOW_PATH.split("/")[:-1])
            REL_FLOW_PATH = FLOW_PATH.split("/")[-1]
            SOURCE_WORKING_DIR = os.path.join(
                SOURCE_SOLUTION_DIR, "CICD", SOURCE_SOLUTION_DIR.split("/")[-1]
            )
            FLOW_NAME = REL_FLOW_PATH.split(".")[0]
        else:
            SOURCE_SOLUTION_DIR = None
            REL_FLOW_PATH = None
            SOURCE_WORKING_DIR = None
            FLOW_NAME = None

        # Target environment config
        target_config = config["target"]
        TARGET_IB_HOST = os.environ.get("TARGET_HOST_URL")
        TARGET_IB_API_TOKEN = os.environ.get("TARGET_TOKEN")
        TARGET_ORG = target_config.get("org")
        TARGET_WORKSPACE = target_config.get("workspace")
        TARGET_IB_PATH = (
            f"{TARGET_ORG}/{TARGET_WORKSPACE}/fs/Instabase Drive/CICD"
            if TARGET_ORG and TARGET_WORKSPACE
            else None
        )

        if args.compile_solution:
            copy_solution_to_working_dir(
                SOURCE_IB_HOST,
                SOURCE_IB_API_TOKEN,
                SOURCE_SOLUTION_DIR,
                REL_FLOW_PATH,
                SOURCE_WORKING_DIR,
            )
            time.sleep(3)
            compile_solution(
                SOURCE_IB_HOST,
                SOURCE_IB_API_TOKEN,
                SOURCE_WORKING_DIR,
                REL_FLOW_PATH,
            )
            time.sleep(3)

        if args.download_solution:
            binary_path = get_latest_binary_path(
                SOURCE_IB_API_TOKEN, SOURCE_IB_HOST, SOURCE_WORKING_DIR
            )
            download_solution(SOURCE_IB_HOST, SOURCE_IB_API_TOKEN, binary_path)
            time.sleep(2)
            delete_folder_or_file_from_ib(
                os.path.join(SOURCE_SOLUTION_DIR, "CICD"),
                SOURCE_IB_HOST,
                SOURCE_IB_API_TOKEN,
                use_clients=False,
            )

            if app_id:
                logging.info("Getting app details...")
                response = get_app_details(
                    SOURCE_IB_HOST, SOURCE_IB_API_TOKEN, SOURCE_ORG, app_id
                )
                details = response.get("solution", {})
                if not details:
                    logging.error("No app details found")
                    return
                save_to_file(details, "app_details.json")

            if deployment_id:
                logging.info("Getting deployment details...")
                response = get_deployment_details(
                    SOURCE_IB_HOST, SOURCE_IB_API_TOKEN, SOURCE_ORG, deployment_id
                )
                save_to_file(response, "deployment_details.json")

        if args.promote_solution_to_target:
            upload_zip_to_instabase(
                TARGET_IB_PATH, TARGET_IB_HOST, TARGET_IB_API_TOKEN, FLOW_NAME
            )

            # Upload the solution binary to target environment
            target_binary_path = os.path.join(
                TARGET_IB_PATH, FLOW_NAME, f"{FLOW_NAME}.ibflowbin"
            )
            binary_content = read_binary("solution.ibflowbin")
            upload_file(
                TARGET_IB_HOST,
                TARGET_IB_API_TOKEN,
                target_binary_path,
                binary_content,
            )
            time.sleep(2)

            # Unzip solution contents
            zip_path = os.path.join(TARGET_IB_PATH, f"{FLOW_NAME}.zip")
            unzip_files(TARGET_IB_HOST, TARGET_IB_API_TOKEN, zip_path)
            time.sleep(3)
            delete_folder_or_file_from_ib(
                zip_path, TARGET_IB_HOST, TARGET_IB_API_TOKEN, use_clients=False
            )

        if args.upload_dependencies:
            dependencies = config["source"].get("dependencies", [])
            requirements_dict = parse_dependencies(dependencies)

            uploaded_ibsolutions = download_dependencies_from_dev_and_upload_to_prod(
                SOURCE_IB_HOST,
                TARGET_IB_HOST,
                SOURCE_IB_API_TOKEN,
                TARGET_IB_API_TOKEN,
                SOURCE_WORKING_DIR,
                TARGET_IB_PATH,
                requirements_dict,
            )
            publish_dependencies(
                uploaded_ibsolutions, TARGET_IB_HOST, TARGET_IB_API_TOKEN
            )

        if args.publish_advanced_app:
            if not app_id:
                logging.error("Source App not provided!")
                return

            app_details = load_from_file("app_details.json")
            solution_path = app_details.get("solution_path")
            if solution_path:
                image_data = read_file_through_api(
                    SOURCE_IB_HOST, SOURCE_IB_API_TOKEN, solution_path + "/icon.png"
                )
                icon_path = os.path.join(TARGET_IB_PATH, FLOW_NAME, "icon.png")
                upload_file(TARGET_IB_HOST, TARGET_IB_API_TOKEN, icon_path, image_data)
            else:
                logging.warning(
                    "Image path not found in app details. Skipping icon upload."
                )

            logging.info("Publishing the advanced app...")
            ibflowbin_path = get_latest_binary_path(
                TARGET_IB_API_TOKEN,
                TARGET_IB_HOST,
                os.path.join(TARGET_IB_PATH, FLOW_NAME),
            )

            payload = {
                "ibflowbin_path": ibflowbin_path,
                "icon_path": icon_path,
                "app_detail": {
                    "name": app_details["name"],
                    "version": app_details["version"],
                    "description": app_details["summary"],
                    "visibility": app_details.get("visibility", "PRIVATE"),
                    "release_notes": app_details["description"],
                    "billing_model": "default",
                },
            }

            response = publish_advanced_app(
                TARGET_IB_HOST, TARGET_IB_API_TOKEN, payload, TARGET_ORG
            )
            new_app_id = check_job_status_build(
                TARGET_IB_HOST, TARGET_IB_API_TOKEN, response["job_id"]
            )
            logging.info("App published successfully.")

        if args.create_deployment:
            if not deployment_id:
                logging.error("Source Deployment not provided!")
                return

            details = load_from_file("deployment_details.json")
            logging.info("Creating the deployment...")

            payload = {
                "name": details["name"],
                "workspace": TARGET_WORKSPACE,
                "deployed_solution_id": new_app_id,
                "description": details["description"],
                "human_review_mode": details["human_review_mode"],
                "human_review_level": details["human_review_level"],
            }
            create_deployment(TARGET_IB_HOST, TARGET_IB_API_TOKEN, payload, TARGET_ORG)
            logging.info("Deployment created successfully.")

    except Exception as e:
        logging.error(f"Error in main: {e}")
        raise


if __name__ == "__main__":
    main()
